

#ifndef _S_UTILS_H_
#define _S_UTILS_H_

#include "common.hpp"


namespace serioso
{
	class utils_c : public object_c
	{
		public:
			static s_long get_milliseconds();

			template<typename T>
				static inline T ** newarray(s_int size)
				{
					T **arr = new T*[size];
					for(s_int i = 0; i < size; i++)
						arr[i] = NULL;

					return arr;
				}

			static inline s_ushort swap16(s_ushort v)  
			{  
				return ((v & 0xff) << 8) | (v >> 8);  
			}  

			static inline s_uint swap32(s_uint v)  
			{  
				return (v >> 24)  
					| ((v & 0x00ff0000) >> 8)  
					| ((v & 0x0000ff00) << 8)  
					| (v << 24);  
			}  

			static inline s_uint64 swap64(s_uint64 v)  
			{  
				return (v >> 56)  
					| ((v & 0x00ff000000000000) >> 40)  
					| ((v & 0x0000ff0000000000) >> 24)  
					| ((v & 0x000000ff00000000) >> 8)  
					| ((v & 0x00000000ff000000) << 8)  
					| ((v & 0x0000000000ff0000) << 24)  
					| ((v & 0x000000000000ff00) << 40)  
					| (v << 56);  
			}

			template <typename T>  
				static inline T swap_endian(T v)
				{
					s_int size = sizeof(v);
					//log_debug("+++++++++++++++++++++++++swap endian 0->%d, %lld", size, v);
					if(size == 4)
					{
						s_uint tv = static_cast<s_uint>(v);
						tv = swap32(tv);
						return static_cast<T>(tv);
					}
					else if(size == 8)
					{
						s_uint64 tv = static_cast<s_uint64>(v);
						tv = swap64(tv);
						return static_cast<T>(tv);
					}
					else if(size == 2)
					{
						s_ushort tv = static_cast<s_ushort>(v);
						//log_debug("+++++++++++++swap 16 1->%d, %d", v, tv);
						tv = swap16(tv);
						//log_debug("+++++++++++++swap 16 2->%d, %d", v, tv);
						return static_cast<T>(tv);
					}

					//log_debug("+++++++++++++++++++++++++swap endian 1->%d, %d", sizeof(v), v);
					return v;
				}
	};
}

#endif
