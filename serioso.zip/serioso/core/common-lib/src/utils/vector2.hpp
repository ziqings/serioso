

#ifndef _S_VECTOR2_H_
#define _S_VECTOR2_H_

#include "common.hpp"

namespace serioso
{
    class vector2_c : public object_c
    {
    public:
        struct
        {
            s_float arr[0];
            s_float x, y;
        };
        
        vector2_c();
        vector2_c(s_float x, s_float y);
        ~vector2_c();
        
        static s_bool sloppyequals(vector2_c a, vector2_c b, s_float tolerance);
    };
}

#endif
