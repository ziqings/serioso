

#include "utils.hpp"

#include <sys/time.h>

namespace serioso
{
    s_long utils_c::get_milliseconds()
    {
        struct timeval tv;
        gettimeofday(&tv,NULL);
        return tv.tv_sec * 1000 + tv.tv_usec / 1000;
    }
}
