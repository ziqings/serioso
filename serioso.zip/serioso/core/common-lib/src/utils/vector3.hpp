

#ifndef _S_VECTOR3_H_
#define _S_VECTOR3_H_

#include "common.hpp"
#include "math.hpp"

namespace serioso
{
    class vector3_c : public object_c
    {
    public:
        /*
         union
         {
         struct
         {
         s_float arr[3];
         };
         
         struct
         {
         s_float x;
         s_float y;
         s_float z;
         };
         };
         */
        
        struct
        {
            s_float arr[0];
            s_float x, y, z;
        };
        
        
        vector3_c();
        vector3_c(s_float x, s_float y, s_float z);
        ~vector3_c();
        
        void zero();
        void copy(vector3_c v3);
        void copy(s_float *v);
        
        vector3_c operator +(vector3_c v3);
        vector3_c operator -(vector3_c v3);
        vector3_c operator *(s_float v);
        vector3_c operator *=(s_float v);
        s_bool operator ==(vector3_c v3);
        s_bool operator !=(vector3_c v3);
        
        void normalize();
        s_float getlength_square();
        
        static vector3_c cross(vector3_c a, vector3_c b);
        static s_float dot(vector3_c v3, vector3_c b);
        static s_float getdistance_square(vector3_c a, vector3_c b);
        static s_float getdistance_2d(vector3_c a, vector3_c b);
        static s_bool isinrange(vector3_c a, vector3_c b, s_float radius, s_float height);
        static s_bool sloppyequals(vector3_c a, vector3_c b, s_float tolerance);
        static vector3_c movetowards(vector3_c a, vector3_c b, s_float speed);
    };
}


#endif
