

#ifndef _S_QUATERNION_H_
#define _S_QUATERNION_H_

#include "common.hpp"

namespace serioso
{
    class quaternion_c : public object_c
    {
    public:
        struct
        {
            s_float arr[0];
            s_float x;
            s_float y;
            s_float z;
            s_float w;
        };
        
        void zero();
    };
}

#endif
