

#include "vector2.hpp"

namespace serioso
{
    vector2_c::vector2_c()
    {
        x = 0;
        y = 0;
    }
    
    vector2_c::vector2_c(s_float x, s_float y)
    {
        this->x = x;
        this->y = y;
    }
    
    vector2_c::~vector2_c()
    {
    }
    
    s_bool vector2_c::sloppyequals(vector2_c a, vector2_c b, s_float tolerance)
    {
        s_float dx = a.x - b.x;
        s_float dy = a.y - b.y;
        
        return (dx * dx + dy * dy) <= tolerance * tolerance;
    }
}
