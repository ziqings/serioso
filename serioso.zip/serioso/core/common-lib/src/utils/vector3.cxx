	

#include "vector3.hpp"

namespace serioso
{
    vector3_c::vector3_c()
    {
        x = 0;
        y = 0;
        z = 0;
    }
    
    vector3_c::vector3_c(s_float x, s_float y, s_float z)
    {
        this->x = x;
        this->y = y;
        this->z = z;
    }
    
    vector3_c::~vector3_c()
    {
    }
    
    void vector3_c::zero()
    {
        memset(arr, 0, sizeof(s_float) * 3);
    }
    
    s_float vector3_c::dot(vector3_c a , vector3_c b)
    {
        return (a.x * b.x + a.y * b.y + a.z * b.z);
    }
    
    vector3_c vector3_c::cross(vector3_c a, vector3_c b)
    {
        vector3_c v3;
        v3.x = a.y * b.z - a.z * b.y;
        v3.y = -a.x * b.z + a.z * b.x;
        v3.z = a.x * b.y - a.y * b.x;
        
        return v3;
    }
    
    vector3_c vector3_c::operator +(vector3_c v3)
    {
        v3.x += x;
        v3.y += y;
        v3.z += z;
        
        return v3;
    }
    
    vector3_c vector3_c::operator -(vector3_c v3)
    {
        v3.x -= x;
        v3.y -= y;
        v3.z -= z;
        
        return v3;
    }
    
    vector3_c vector3_c::operator *(s_float v)
    {
        vector3_c v3;
        v3.x = x * v;
        v3.y = y * v;
        v3.z = z * v;
        
        return v3;
    }
    
    vector3_c vector3_c::operator *=(s_float v)
    {
        vector3_c v3;
        v3.x = x * v;
        v3.y = y * v;
        v3.z = z * v;
        
        return v3;
    }
    
    s_bool vector3_c::operator ==(vector3_c v3)
    {
        return (x == v3.x) && (y == v3.y) && (z == v3.z);
    }
    
    s_bool vector3_c::operator !=(vector3_c v3)
    {
        return (x != v3.x) || (y != v3.y) || (z != v3.z);
    }
    
    void vector3_c::normalize()
    {
        float m = s_sqrt(x * x + y * y + z * z);
        if(m < S_TOLERANCE)
            m = 1;
        
        x /= m;
        y /= m;
        z /= m;
        
        if(s_abs(x) < S_TOLERANCE)
            x = 0;
        if(s_abs(y) < S_TOLERANCE)
            y = 0;
        if(s_abs(z) < S_TOLERANCE)
            z = 0;
    }
    
    s_float vector3_c::getlength_square()
    {
        return (x * x + y * y + z * z);
    }
    
    s_float vector3_c::getdistance_square(vector3_c a, vector3_c b)
    {
        vector3_c d = a - b;
        
        return (d.x * d.x + d.y * d.y + d.z * d.z);
    }
    
    s_float vector3_c::getdistance_2d(vector3_c a, vector3_c b)
    {
        float dx = a.x - b.x;
        float dz = a.z - b.z;
        
        return s_sqrt(dx * dx + dz * dz);
    }
    
    s_bool vector3_c::isinrange(vector3_c a, vector3_c b, s_float radius, s_float height)
    {
        vector3_c d = b - a;
        
        return (d.x * d.x + d.z * d.z) < (radius * radius) && (s_abs(d.y) < height);
    }
    
    s_bool vector3_c::sloppyequals(vector3_c a, vector3_c b, s_float tolerance)
    {
        vector3_c d = a - b;
        
        return (d.x * d.x + d.y * d.y + d.z * d.z) <= tolerance * tolerance;
    }
    
    void vector3_c::copy(vector3_c v3)
    {
        memcpy(arr, v3.arr, sizeof(s_float) * 3);
    }
    
    void vector3_c::copy(s_float *v)
    {
        s_assert(v != NULL);
        memcpy(arr, v, sizeof(s_float) * 3);
    }
    
    vector3_c vector3_c::movetowards(vector3_c a, vector3_c b, s_float speed)
    {
        vector3_c vec;
        
        return vec;
    }
}
