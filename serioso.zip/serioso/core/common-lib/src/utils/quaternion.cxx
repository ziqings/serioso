

#include "quaternion.hpp"

namespace serioso
{
    void quaternion_c::zero()
    {
        memset(arr, 0, sizeof(s_float) * 4);
    }
}

