

#include "platform.hpp"
#include "log.hpp"

#include "default_platform.hpp"

#ifdef WIN

#include "windows_platform.hpp"

#endif

namespace serioso
{
	platform_i *platform_c::plat = NULL;

	void platform_c::init()
	{
#ifdef WIN
		platform_c::plat = new windows_platform_c();
#else
		platform_c::plat = new default_platform_c();
#endif
	}

	union check_endian_u
	{
		int a;
		char b;
	};

	//platform_i
	static s_bool check_little_endian()
	{
		check_endian_u ceu;
		ceu.a = 1;

		if(ceu.b == 1)
			return true;
		else
			return false;
	}

	platform_i::platform_i()
	{
		little_endian = check_little_endian();
	}

	platform_i::~platform_i()
	{
	}
}
