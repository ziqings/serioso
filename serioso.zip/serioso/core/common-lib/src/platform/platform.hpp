
#ifndef _S_PLATFORM_H_
#define _S_PLATFORM_H_

#include "common.hpp"


namespace serioso
{
	class platform_i : public object_c
	{
		public:
			virtual void stacktrace() = 0;
			inline s_bool is_little_endian(){return little_endian;}

			platform_i();
			~platform_i();

		private:
			s_bool little_endian;
	};

	class platform_c : public object_c
	{
		public:
			static void init();
			static inline platform_i * getcurrent(){return plat;}

		private:
			static platform_i *plat;
	};
}

#endif
