

#ifndef _S_WINDOWSPLATFORM_H_
#define _S_WINDOWSPLATFORM_H_

#include "platform.hpp"


#ifdef WIN

namespace serioso
{
	class windows_platform_c : public platform_i 
	{
		public:
			void stacktrace();

			/*
			windows_platform_c();
			~windows_platform_c();
			*/
	};
};

#endif

#endif
