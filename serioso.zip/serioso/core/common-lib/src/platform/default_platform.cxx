

#include "default_platform.hpp"

namespace serioso
{
	void default_platform_c::stacktrace()
	{
	}
}
