

#ifndef _S_DEFAULTPLATFORM_H_
#define _S_DEFAULTPLATFORM_H_

#include "platform.hpp"


namespace serioso
{
	class default_platform_c : public platform_i
	{
		public:
			void stacktrace();
	};
}

#endif
