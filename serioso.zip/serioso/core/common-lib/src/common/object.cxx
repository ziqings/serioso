

#include "object.hpp"


namespace serioso
{
	void * object_c::operator new(size_t size)
	{
		return memory_alloc(size);
	}

	void object_c::operator delete(void *ptr)
	{
		memory_free(ptr);
	}
}
