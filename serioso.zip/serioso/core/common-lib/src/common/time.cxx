

#include "time.hpp"

namespace serioso
{
    s_float time_c::_realtime_f = 0;
    s_long time_c::_realtime_l = 0;
    s_float time_c::_deltatime_f = 0;
    s_long time_c::_deltatime_l = 0;
    
    void time_c::update(s_long curtime)
    {
        if(_realtime_l == 0)
            _realtime_l = curtime;
        _deltatime_l = curtime - _realtime_l;
        _deltatime_f = _deltatime_l * 0.001f;
        _realtime_l = curtime;
        _realtime_f = _realtime_l * 0.001f;
    }
}

