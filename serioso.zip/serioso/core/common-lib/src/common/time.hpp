

#ifndef _S_TIME_H_
#define _S_TIME_H_

#include "common.hpp"

namespace serioso
{
	class time_c
	{
		public:
			static void update(s_long curtime);

			static inline s_float realtime_f(){return _realtime_f;}
			static inline s_long realtime_l(){return _realtime_l;}
			static inline s_float deltatime_f(){return _deltatime_f;}
			static inline s_long deltatime_l(){return _deltatime_l;}

		private:
			static s_float _realtime_f;
			static s_long _realtime_l;
			static s_float _deltatime_f;
			static s_long _deltatime_l;
	};
}

#endif
