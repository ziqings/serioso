

#ifndef _LLUA_H_
#define _LLUA_H_

extern "C"
{
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
}


int llua_beginpcall(lua_State *, int);
int llua_error(lua_State *, const char *);
int llua_pusherror(lua_State *, const char *, ...);
int llua_traceback(lua_State *);
void llua_reg_module(lua_State *, const char *, const luaL_Reg *funcs);

#endif //_LLUA_H_
