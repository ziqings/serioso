

#ifndef _S_BYTEBUFFER_H_
#define _S_BYTEBUFFER_H_

#include <vector>

#include "common.hpp"
#include "log.hpp"
#include "platform.hpp"
#include "utils.hpp"

using namespace std;


namespace serioso
{
#define BUFFER_SIZE 4096
    
    class bytebuffer_c : public object_c
    {
    public:
        bytebuffer_c(s_int size = BUFFER_SIZE);
        ~bytebuffer_c(){}
        
        s_int remaining();
        void clear();
        void resize(s_int size);
        s_int size();
        
        s_byte peek() const;
        s_byte get() const;
        s_byte get(s_int index) const;
        void get_bytes(s_byte *buf, s_int len) const;
		const s_byte * get_bytes() const;
        s_double get_double() const;
        s_double get_double(s_int index) const;
        s_float get_float() const;
        s_float get_float(s_int index) const;
        s_int get_int() const;
        s_int get_int(s_int index) const;
        s_long get_long() const;
        s_long get_long(s_int index) const;
        s_short get_short() const;
        s_short get_short(s_int index) const;
        s_ushort get_ushort() const;
        s_ushort get_ushort(s_int index) const;
        
        void put(bytebuffer_c *src);
        void put(s_byte b);
        void put(s_byte b, s_int index);
        void put_bytes(const s_byte *buf, s_int len);
        void put_bytes(const s_byte *buf, s_int len, s_int index);
        void put_double(s_double v);
        void put_double(s_double v, s_int index);
        void put_float(s_float v);
        void put_float(s_float v, s_int index);
        void put_int(s_int v);
        void put_int(s_int v, s_int index);
        void put_long(s_long v);
        void put_long(s_long v, s_int index);
        void put_short(s_short v);
        void put_short(s_short v, s_int index);
        void put_ushort(s_ushort v);
        void put_ushort(s_ushort v, s_int index);
        
        inline void set_readpos(s_int index){rpos = index;}
        inline s_int get_readpos(){return rpos;}
        inline void set_writepos(s_int index){wpos = index;}
        inline s_int get_writepos(){return wpos;}
        inline s_int get_id(){return id;}
        inline void set_id(s_int v){id = v;}
        inline void set_little_endian(s_bool little){little_endian = little;}
        
    private:
        s_int id;
        s_int wpos;
        mutable s_int rpos;
        s_bool little_endian;
        vector<s_byte> buffer;
        
        
        template<typename T, typename T1> T1 read() const
        {
            T1 data = read<T, T1>(rpos);
            rpos += sizeof(T);
            return data;
        }
        
        template<typename T, typename T1> T1 read(s_int index) const
        {
            if (index + sizeof(T) <= buffer.size())
            {
                T v = *((T*) &buffer[index]);
                
                if(little_endian == platform_c::getcurrent()->is_little_endian())
                {
                    return v.x;
                }
                else
                {
                    return utils_c::swap_endian<T1>(v.x);
                }
            }
            return 0;
        }
        
        template<typename T> void append(T data)
        {
            s_int s = sizeof(data);
            
            if (size() < (wpos + s))
                buffer.resize(wpos + s);
            if(little_endian != platform_c::getcurrent()->is_little_endian())
            {
                data = utils_c::swap_endian<T>(data);
            }
            
            memcpy(&buffer[wpos], (s_byte *) &data, s);
            
            wpos += s;
        }
        
        template<typename T> void insert(T data, s_int index) 
        {
            if ((index + sizeof(data)) > size())
                return;
            
            if(little_endian != platform_c::getcurrent()->is_little_endian())
                data = utils_c::swap_endian<T>(data);
            
            memcpy(&buffer[index], (s_byte *) &data, sizeof(data));
            wpos = index + sizeof(data);
        }
    };
}

#endif
