

#ifndef _S_EVENT_H_
#define _S_EVENT_H_

#include <vector>

#include "common.hpp"

namespace serioso
{
	class eventargs_c : public object 
	{
	};

	class eventhandler_c : public object
	{
		public:
			eventhandler_c(s_byte t){htype = t;}
			virtual ~eventhandler_c(){}

			virtual void handler(const void *arg) = 0;
			virtual s_bool compare(const eventHandler *h)
			{
				if(h->htype != htype)
					return false;

				return true;
			}

		protected:
			s_byte htype;
	};

	template<typename T1, typename T2>
		class member_eventhandler_c : public eventhandler_c
	{
		public:
			typedef void (T2::*fn)(const T1 *arg);

			member_eventhandler_c(T2 *t, fn f):eventhandler_c(0){this->t = t;func = f;}
			~member_eventhandler_c(){}

			void handler(const void *arg)
			{
				(t->* func)((T1 *)arg);
			}

			s_bool compare(const eventhandler_c *h)
			{
				if(!eventhandler_c::compare(h))
					return false;

				const member_eventhandler_c *mh = (const member_eventhandler_c *)h;
				if(mh->t == t && mh->func == func)
					return true;

				return false;
			}

		private:
			fn func;
			T2 *t;
	};

	template<typename T>
		class static_eventhandler_c : public eventhandler_c
	{
		public:
			typedef void (*fn)(const T *arg);

			static_eventhandler_c(fn f):eventhandler_c(1){func = f;}
			~static_eventhandler_c(){}

			void handler(const void *arg)
			{
				func((T *)arg);
			}

			s_bool compare(const eventhandler_c *h)
			{
				if(!eventhandler_c::compare(h))
					return false;

				const static_eventhandler_c *sh = (const static_eventhandler_c *)h;
				if(sh->func == func)
					return true;

				return false;
			}

		private:
			fn func;
	};

#define eventhandler_static(T, fn) (new static_eventhandler_c<T>(f))
#define eventhandler_member(T1, T2, t, fn) (new member_eventhandler_c<T1, T2>(t, fn))

	template<typename T>
		class event : public object
	{
		protected:
			virtual void add(eventhandler_c *h)
			{
				if(h == NULL)
					return;
				pool.push_back(h);
			}

			virtual void remove(eventhandler_c *h)
			{
				if(h == NULL)
					return;
				for(typename vector<eventhandler_c *>::iterator it = pool.begin(); it != pool.end(); it++)
				{
					if((*it)->compare(h))
					{
						pool.erase(it);
						delete *it;
						break;
					}
				}

				delete h;
			}

		public:
			event(){}
			~event(){}

			event & operator +=(eventhandler_c *h)
			{
				add(h);
				return *this;
			}

			event & operator -=(eventhandler_c *h)
			{
				remove(h);
				return *this;
			}

			void dispatch(const T *arg)
			{
				for(typename vector<eventhandler_c *>::iterator it = pool.begin(); it != pool.end(); it++)
				{
					(*it)->handler(arg);
				}
			}

		private:
			vector<eventhandler_c *> pool;
	};
}

#endif
