

#ifndef _S_OBJECT_H_
#define _S_OBJECT_H_

#include "common.hpp"


namespace serioso
{
	class object_c
	{
		public:
			void * operator new(size_t size);
			void operator delete(void *ptr);
	};
}

#endif
