

#ifndef _SCOMMON_H_
#define _SCOMMON_H_

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "type.hpp"
#include "memory.hpp"
#include "object.hpp"
#include "log.hpp"

namespace serioso
{
#define WIN
#define LUA


#define EXPORT_API extern "C"

#define s_assert assert
#define s_static_assert(a, str) if(a == 0){printf(str); s_assert(a);}

}

#endif
