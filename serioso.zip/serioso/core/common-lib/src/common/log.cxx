

#include "log.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdarg.h>

#include "../platform/platform.hpp"


namespace serioso
{
	static debug_func debug_log = NULL;

	static pthread_mutex_t loglock;
	static pthread_mutex_t stacklock;
	static const int LOGBUFFLEN = 1024 * 64;
	static char logbuf[LOGBUFFLEN];


	void log_stacktrace()
	{
		platform_c::getcurrent()->stacktrace();
	}

	void log_init(debug_func func)
	{
		debug_log = func;
		pthread_mutex_init(&loglock, NULL);
		pthread_mutex_init(&stacklock, NULL);
	}

	void log_debug(const char *format, ...)
	{
		if(format == NULL)
			return;
		if(debug_log != NULL)
		{
			pthread_mutex_lock(&loglock);

			va_list arglist;
			va_start(arglist, format);
			vsnprintf(logbuf, LOGBUFFLEN, format, arglist); 
			va_end(arglist);

			debug_log(logbuf);
			pthread_mutex_unlock(&loglock);
		}
	}
}
