

#include "bytebuffer.hpp"



namespace serioso
{
#ifdef WIN
#define PACKED_DECL
#pragma pack(1)
#else
#define PACKED_DECL __attribute__((packed))
#endif
    
    struct _us_uint64{s_uint64 x PACKED_DECL;};
    struct _us_uint32{s_uint x PACKED_DECL;};
    struct _us_uint16{s_ushort x PACKED_DECL;};
    struct _us_int64{s_int64 x PACKED_DECL;};
    struct _us_int32{s_int x PACKED_DECL;};
    struct _us_int16{s_short x PACKED_DECL;};
    struct _us_float{s_float x PACKED_DECL;};
    struct _us_double{s_double x PACKED_DECL;};
    struct _us_byte{s_byte x PACKED_DECL;};
    
#ifdef WIN
#pragma pack
#endif
    
    bytebuffer_c::bytebuffer_c(s_int size)
    {
        id = -1;
        buffer.reserve(size);
        little_endian = true;
        clear();
    }
    
    s_int bytebuffer_c::remaining()
    {
        return wpos - rpos;
    }
    
    void bytebuffer_c::clear()
    {
        rpos = 0;
        wpos = 0;
        buffer.clear();
    }
    
    void bytebuffer_c::resize(s_int size)
    {
        buffer.resize(size);
        rpos = 0;
        wpos = 0;
    }
    
    s_int bytebuffer_c::size()
    {
        return buffer.size();
    }
    
    s_byte bytebuffer_c::peek() const
    {
        return read<_us_byte, s_byte>(rpos);
    }
    
    s_byte bytebuffer_c::get() const
    {
        return read<_us_byte, s_byte>();
    }
    
    s_byte bytebuffer_c::get(s_int index) const
    {
        return read<_us_byte, s_byte>(index);
    }
    
    void bytebuffer_c::get_bytes(s_byte *buf, s_int len) const
    {
        for(s_int i = 0; i < len; i++)
        {
            buf[i] = read<_us_byte, s_byte>();
        }
    }

	const s_byte * bytebuffer_c::get_bytes() const
	{
		return (s_byte *)(&buffer[rpos]);
	}
    
    s_double bytebuffer_c::get_double() const
    {
        return read<_us_double, s_double>();
    }
    
    s_double bytebuffer_c::get_double(s_int index) const
    {
        return read<_us_double, s_double>(index);
    }
    
    s_float bytebuffer_c::get_float() const
    {
        return read<_us_float, s_float>();
    }
    
    s_float bytebuffer_c::get_float(s_int index) const
    {
        return read<_us_float, s_float>(index);
    }
    
    s_int bytebuffer_c::get_int() const
    {
        return read<_us_int32, s_int>();
    }
    
    s_int bytebuffer_c::get_int(s_int index) const
    {
        return read<_us_int32, s_int>(index);
    }
    
    s_long bytebuffer_c::get_long() const
    {
        return read<_us_int64, s_long>();
    }
    
    s_long bytebuffer_c::get_long(s_int index) const
    {
        return read<_us_int64, s_long>(index);
    }
    
    s_short bytebuffer_c::get_short() const
    {
        return read<_us_int16, s_short>();
    }
    
    s_short bytebuffer_c::get_short(s_int index) const
    {
        return read<_us_int16, s_short>(index);
    }
    
    s_ushort bytebuffer_c::get_ushort() const
    {
        return read<_us_uint16, s_ushort>();
    }
    
    s_ushort bytebuffer_c::get_ushort(s_int index) const
    {
        return read<_us_uint16, s_ushort>(index);
    }
    
    void bytebuffer_c::put(bytebuffer_c *src)
    {
    }
    
    void bytebuffer_c::put(s_byte b)
    {
        append<s_byte>(b);
    }
    
    void bytebuffer_c::put(s_byte b, s_int index)
    {
        insert<s_byte>(b, index);
    }
    
    void bytebuffer_c::put_bytes(const s_byte *buf, s_int len)
    {
        for(s_int i = 0; i < len; i++)
            append<s_byte>(buf[i]);
    }
    
    void bytebuffer_c::put_bytes(const s_byte *buf, s_int len, s_int index)
    {
        wpos = index;
        for(s_int i = 0; i < len; i++)
            append<s_byte>(buf[i]);
    }
    
    void bytebuffer_c::put_double(s_double v)
    {
        append<s_double>(v);
    }
    
    void bytebuffer_c::put_double(s_double v, s_int index)
    {
        insert<s_double>(v, index);
    }
    
    void bytebuffer_c::put_float(s_float v)
    {
        append<s_float>(v);
    }
    
    void bytebuffer_c::put_float(s_float v, s_int index)
    {
        insert<s_float>(v, index);
    }
    
    void bytebuffer_c::put_int(s_int v)
    {
        append<s_int>(v);
    }
    
    void bytebuffer_c::put_int(s_int v, s_int index)
    {
        insert<s_int>(v, index);
    }
    
    void bytebuffer_c::put_long(s_long v)
    {
        append<s_long>(v);
    }
    
    void bytebuffer_c::put_long(s_long v, s_int index)
    {
        insert<s_long>(v, index);
    }
    
    void bytebuffer_c::put_short(s_short v)
    {
        append<s_short>(v);
    }
    
    void bytebuffer_c::put_short(s_short v, s_int index)
    {
        insert<s_short>(v, index);
    }
    
    void bytebuffer_c::put_ushort(s_ushort v)
    {
        append<s_ushort>(v);
    }
    
    void bytebuffer_c::put_ushort(s_ushort v, s_int index)
    {
        insert<s_ushort>(v, index);
    }
}
