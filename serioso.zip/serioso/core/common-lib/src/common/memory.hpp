

#ifndef _S_MEMORY_H_
#define _S_MEMORY_H_

#include "common.hpp"


namespace serioso
{
	typedef void * (alloc_func)(s_int size);
	typedef void (free_func)(void *ptr);


	void memory_setfunc(alloc_func *alloc, free_func *freeFunc);
	void * memory_alloc(s_int size);
	void memory_free(void *ptr);
}

#endif
