

#ifndef _S_QUEUE_SF_H_
#define _S_QUEUE_SF_H_

#include "common.hpp"

#include <vector>
#include <queue>
#include <pthread.h>

using namespace std;


namespace serioso
{
	template <typename T>
		class queue_sf_c : public object_c
	{
		public:
			queue_sf_c(){pthread_mutex_init(&lock, NULL);}
			~queue_sf_c(){}

			void enqueue(T v);
			s_int dequeue(T *v);
			s_int size();


		private:
			pthread_mutex_t lock;
			queue<T> data;
	};

	template <typename T>
	s_int queue_sf_c<T>::size()
	{
		int re = 0;
		pthread_mutex_lock(&lock);
		re = data.size();
		pthread_mutex_unlock(&lock);

		return re;
	}

	template <typename T>
		void queue_sf_c<T>::enqueue(T v)
		{
			pthread_mutex_lock(&lock);
			data.push(v);
			pthread_mutex_unlock(&lock);
		}

	template <typename T>
		s_int queue_sf_c<T>::dequeue(T *v)
		{
			T t;
			s_int re = -1;
			pthread_mutex_lock(&lock);
			if(data.size() > 0)
			{
				t = data.front();
				data.pop();
				re = 0;
			}
			pthread_mutex_unlock(&lock);

			if(re == 0)
				*v = t;

			return re;
		}
}

#endif
