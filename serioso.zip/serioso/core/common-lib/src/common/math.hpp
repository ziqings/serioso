

#ifndef _SMATH_H_
#define _SMATH_H_

#include "common.hpp"

#include <math.h>

namespace serioso
{
#define s_max(x, y) (x > y ? x : y)
#define s_min(x, y) (x < y ? x : y)
#define s_abs(x) abs(x)
#define s_sqrt(x) sqrt(x)

#define S_TOLERANCE 0.0001f

	float math_rand_float();

	template<typename T>
		void math_array_reverse(T *arr, s_int len)
		{
			s_int hlen = len / 2;
			T t = NULL;
			for(s_int i = 0; i < hlen; i++)
			{
				t = arr[i];
				arr[i] = arr[len - i];
				arr[len - i] = t;
			}
		}
}

#endif
