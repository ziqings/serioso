

#ifndef _S_LOG_H_
#define _S_LOG_H_


namespace serioso
{
	typedef void (*debug_func)(const char *);

	void log_stacktrace();

	void log_init(debug_func func);
	void log_debug(const char *fmt, ...);
}

#endif
