

#include "memory.hpp"


namespace serioso
{
	static void * alloc_default(s_int size)
	{
		return malloc(size);
	}

	static void free_default(void *ptr)
	{
		free(ptr);
	}

	static alloc_func *alloc_f = alloc_default;
	static free_func *free_f = free_default;


	void memory_setfunc(alloc_func *allocf, free_func *freef)
	{
		alloc_f = allocf;
		free_f = freef;
	}

	void * memory_alloc(s_int size)
	{
		return alloc_f(size);
	}

	void memory_free(void *ptr)
	{
		if(ptr)
			free_f(ptr);
	}
}
