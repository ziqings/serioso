

#ifndef _S_TASK_H_
#define _S_TASK_H_

#include "common.hpp"
#include "log.hpp"


namespace serioso
{
	class state_i : public object_c
	{
		public:
			virtual s_bool enter() = 0;
			virtual s_bool update() = 0;
			virtual void exit() = 0;
	};

	template<typename T>
		class condition_i : public object_c
	{
		public:
			virtual s_bool evaluate(T *t) = 0;
	};

	class taskstate_e
	{
		public:
			enum ENUM
			{
				TS_INACTIVE = 0,
				TS_ACTIVE = 1,
				TS_FAILED = 2,
				TS_COMPLETE = 3,
				TS_EXITING = 4,
			};
	};

	template<typename T>
		class task_i : public object_c
	{
		public:
			virtual taskstate_e::ENUM getstate() = 0;
			virtual taskstate_e::ENUM update(T *t) = 0;
			virtual s_bool exit(T *t) = 0;
	};

	template<typename T>
		class basetask_c : public task_i<T>
	{
		public:
			basetask_c(){state = taskstate_e::TS_INACTIVE;}
			~basetask_c(){}

			taskstate_e::ENUM getstate(){return state;}
			taskstate_e::ENUM update(T *t)
			{
				if(state == taskstate_e::TS_ACTIVE || state == taskstate_e::TS_INACTIVE)
					localupdate(t);
				else
					state = taskstate_e::TS_FAILED;

				return state;
			}

			s_bool exit(T *t)
			{
				if(state == taskstate_e::TS_INACTIVE || localexit(t))
				{
					state = taskstate_e::TS_INACTIVE;
					return true;
				}
				else
				{
					state = taskstate_e::TS_EXITING;
					return false;
				}
			}

		protected:
			taskstate_e::ENUM state;
			virtual void localupdate(T *t) = 0;
			virtual s_bool localexit(T *t){return true;}
	};

	template<typename T>
		class sequentialtask_c : public basetask_c<T>
	{
		public:
			sequentialtask_c(s_int size)
			{
				size = s_max(1, size);
				tasksize = size;
				count = 0;
				selectedtask = 0;
				tasks = utils_c::newarray<task_i<T> >(size);
			}

			~sequentialtask_c(){delete[] tasks;}

			inline static sequentialtask_c * create(s_int size){return new sequentialtask_c(size);}
			sequentialtask_c * load(task_i<T> *task)
			{
				log_debug("sequential node load 1->%d, %d, %d\n", (task == NULL), count, tasksize);
				if(task == NULL || count == tasksize)
					return NULL;

				log_debug("sequential node load 2\n");
				tasks[count++] = task;
				log_debug("sequential node load 3\n");

				return this;
			}

		protected:
			void localupdate(T *t)
			{
				if(this->state == taskstate_e::TS_INACTIVE)
				{
					if(count == 0)
					{
						this->state = taskstate_e::TS_COMPLETE;
						return;
					}

					selectedtask = 0;
					this->state = taskstate_e::TS_ACTIVE;
				}

				this->state = tasks[selectedtask]->update(t);

				if(this->state == taskstate_e::TS_COMPLETE)
				{
					if(++selectedtask < tasksize)
						this->state = taskstate_e::TS_ACTIVE;
					else
						selectedtask--;
				}
			}

			s_bool localexit(T *t)
			{
				while(selectedtask != -1)
				{
					if(tasks[selectedtask]->exit(t))
						selectedtask--;
					else
						return false;
				}

				return true;
			}

		private:
			task_i<T> **tasks;
			s_int tasksize;
			s_int count;
			s_int selectedtask;
	};

	template<typename T>
		class paralleltask_c : public basetask_c<T>
	{
		public:
			paralleltask_c(s_int size)
			{
				tasksize = s_max(1, size);
				tasks = utils::newarray<task_i<T> >(tasksize);
				count = 0;
			}

			~paralleltask_c(){delete[] tasks;}

			inline static paralleltask_c * create(s_int size){return new paralleltask_c(size);}

			paralleltask_c * load(task_i<T> *task)
			{
				if(task == NULL || count == tasksize)
					return NULL;

				tasks[count++] = task;

				return this;
			}

		protected:
			void localupdate(T *t)
			{
				s_bool isfirstupdate = false;
				if(this->state == taskstate_e::TS_INACTIVE)
				{
					isfirstupdate = true;
					this->state = taskstate_e::TS_ACTIVE;
				}

				s_int completioncount = 0;

				task_i<T> *task = NULL;
				taskstate_e::ENUM childstate;
				for(s_int i = 0; i < count; i++)
				{
					task = tasks[i];
					childstate = task->getstate();
					if(isfirstupdate || childstate == taskstate_e::TS_ACTIVE)
					{
						childstate = task->Update(t);
						if(childstate == taskstate_e::TS_COMPLETE)
							completioncount++;
						else if(childstate == taskstate_e::TS_FAILED)
						{
							this->state = taskstate_e::TS_FAILED;
							return;
						}
					}
				}

				if(taskSize == completioncount)
					this->state = taskstate_e::TS_COMPLETE;
			}

			s_bool localexit(T *t)
			{
				s_bool exitcomplete = true;
				for(s_int i = count - 1; i > -1; i--)
				{
					if(tasks[i]->getstate() == taskstate_e::TS_INACTIVE && !tasks[i]->exit(t))
						exitcomplete = false;
				}

				return exitcomplete;
			}

		private:
			task_i<T> **tasks;
			s_int tasksize;
			s_int count;
	};

	template<typename T>
		class priorityselector_c : public basetask_c<T>
	{
		public:
			static priorityselector_c * create(s_int size)
			{
				return new priorityselector_c(size);
			}

			priorityselector_c * load(condition_i<T> *condition, task_i<T> *task)
			{
				if(condition == NULL || task == NULL || count == taskSize)
					return NULL;

				conditions[count] = condition;
				tasks[count] = task;
				count++;

				return this;
			}

		protected:
			void localupdate(T *t)
			{
				if(this->state == taskstate_e::TS_INACTIVE)
				{
					selectedtask = NONE;
					for(s_int i = 0; i < tasksize; i++)
					{
						if(conditions[i]->evaluate(t))
						{
							selectedtask = i;
							break;
						}
					}

					if(selectedtask == NONE)
					{
						this->state = taskstate_e::TS_COMPLETE;
						return;
					}

					this->state = taskstate_e::TS_ACTIVE;
				}

				this->state = tasks[selectedtask]->update(t);
			}

			s_bool localexit(T *t)
			{
				if(selectedtask != NONE && !tasks[selectedtask]->exit(t))
					return false;

				selectedtask = NONE;
				return true;
			}

			~priorityselector_c()
			{
				delete[] conditions;
				delete[] tasks;
			}

		private:
			const static s_int NONE = -1;
			condition_i<T> **conditions;
			task_i<T> **tasks;
			s_int tasksize;
			s_int count;
			s_int selectedtask;

			priorityselector_c(s_int size)
			{
				tasksize = s_max(1, size);
				conditions = new condition_i<T> *[tasksize];
				tasks = new task_i<T> *[tasksize];
				count = 0;
				selectedtask = 0;
			}
	};

	template<typename T>
		class task_c : public object_c 
	{
		public:
			static s_bool isfinished(taskstate_e::ENUM state)
			{
				return (state == taskstate_e::TS_COMPLETE || state == taskstate_e::TS_FAILED);
			}

			static s_bool isrunnable(taskstate_e::ENUM state)
			{
				return (state == taskstate_e::TS_INACTIVE || state == taskstate_e::TS_ACTIVE);
			}

			static s_bool process(T *t, task_i<T> *task, s_bool &failure)
			{
				failure = false;
				switch(task->getstate())
				{
					case taskstate_e::TS_ACTIVE:
						task->update(t);
						return true;
					case taskstate_e::TS_COMPLETE:
						return !task->exit(t);
					case taskstate_e::TS_EXITING:
						return !task->exit(t);
					case taskstate_e::TS_FAILED:
						failure = true;
						return !task->exit(t);
					case taskstate_e::TS_INACTIVE:
						task->update(t);
						return true;
				}

				return true;
			}

			static s_bool process(T *t, task_i<T> *task)
			{
				switch(task->getstate())
				{
					case taskstate_e::TS_ACTIVE:
						task->update(t);
						return true;
					case taskstate_e::TS_COMPLETE:
						return !task->exit(t);
					case taskstate_e::TS_EXITING:
						return !task->exit(t);
					case taskstate_e::TS_FAILED:
						return !task->exit(t);
					case taskstate_e::TS_INACTIVE:
						task->update(t);
						return true;
				}

				return true;
			}

			static s_bool processimmediate(T *t, task_i<T> *task)
			{
				switch(task->getstate())
				{
					case taskstate_e::TS_ACTIVE:
						if(isfinished(task->update(t)))
							return !task->exit(t);
						return true;
					case taskstate_e::TS_COMPLETE:
						return !task->exit(t);
					case taskstate_e::TS_EXITING:
						return !task->exit(t);
					case taskstate_e::TS_FAILED:
						return !task->exit(t);
					case taskstate_e::TS_INACTIVE:
						if(isfinished(task->update(t)))
							return !task->exit(t);
						return true;
				}

				return true;
			}
	};
}

#endif
