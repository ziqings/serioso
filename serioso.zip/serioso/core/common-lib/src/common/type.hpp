

#ifndef _S_TYPE_H_
#define _S_TYPE_H_

namespace serioso
{
#define s_ushort unsigned short
#define s_short short
#define s_uint unsigned int
#define s_int int
#define s_int64 long long int
#define s_uint64 unsigned long long int
#define s_long long long int
#define s_ulong unsigned long long int
#define s_float float
#define s_double double
#define s_byte unsigned char
#define s_bool bool
}

#endif
