

#include <string.h>
#include<cstdlib>

#include "math.hpp"

using namespace std;


namespace serioso
{
	float math_rand_float()
	{
		return (float)rand();
	}
}
