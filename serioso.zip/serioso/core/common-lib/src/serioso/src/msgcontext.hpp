
#ifndef _MSGCONTEXT_H_
#define _MSGCONTEXT_H_

#include "llua.hpp"


struct MsgContext;

const MsgContext * msgcontext_gennew(int len);

int msgcontext_set(const MsgContext *, int gID, int uID, const char *data, int len);

int msgcontext_lget(const MsgContext *, lua_State *);
int msgcontext_get(const MsgContext *, int &, int &, char *, int);

int msgcontext_capacity(const MsgContext *);
bool msgcontext_active(const MsgContext *);

#endif //_MSGCONTEXT_H_
