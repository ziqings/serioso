

#include <vector>
#include <queue>
#include <pthread.h>

#ifdef WIN32
#include <Malloc.h>
#else
#include <stdlib.h>
#endif

#include "serioso.hpp"

using namespace std;

struct SQueue
{
	int id;
	bool active;
	pthread_mutex_t lock;
	queue<void *> data;
};

static vector<SQueue *> squeues;
static queue<int> idlequeues;
static pthread_mutex_t queuelock;


void squeue_init()
{
	pthread_mutex_init(&queuelock, NULL);
}

const SQueue * squeue_gennew()
{
	int index = -1;

	pthread_mutex_lock(&queuelock);
	if(idlequeues.size() > 0)
	{
		index = idlequeues.front();
		idlequeues.pop();
	}
	else
	{
		index = squeues.size();
		SQueue *q = new SQueue();
		squeues.push_back(q);
	}
	pthread_mutex_unlock(&queuelock);

	if(index <= 0)
		return NULL;

	SQueue *re = squeues[index];
	re->id = index;
	re->active = true;
	pthread_mutex_init(&(re->lock), NULL);

	return re;
}

void squeue_dispose(const SQueue *sq)
{
	if(sq == NULL)
		return;
	if(!sq->active)
		return;

	pthread_mutex_lock(&queuelock);

	SQueue *squ = squeues[sq->id];
	squ->active = false;

	idlequeues.push(squ->id);

	pthread_mutex_unlock(&queuelock);
}

int squeue_enqueue(const SQueue *sq, void *data)
{
	if(sq == NULL)
		return -1;

	if(!sq->active)
		return -2;

	SQueue *squ = squeues[sq->id];
	pthread_mutex_lock(&(squ->lock));
	squ->data.push(data);
	pthread_mutex_unlock(&(squ->lock));
	return 0;
}

void * squeue_dequeue(const SQueue *sq)
{
	if(sq == NULL)
		return NULL;

	if(!sq->active)
		return NULL;

	SQueue *squ = squeues[sq->id];
	if(squ == NULL)
	{
		serioso_debug("squeue_dequeue queue is null->%d", sq->id);
		return NULL;
	}

	pthread_mutex_lock(&(squ->lock));
	void * re = NULL;
	if(squ->data.size() > 0)
	{
		re = squ->data.front();
		squ->data.pop();
	}
	pthread_mutex_unlock(&(squ->lock));

	return re;
}
