

#ifndef _MSGPOOL_H_
#define _MSGPOOL_H_

#include "msgcontext.hpp"

void msgpool_init(int, int);
const MsgContext * msgpool_gencontext(int);
void msgpool_recyclecontext(const MsgContext *);

#endif //_MSGPOOL_H_
