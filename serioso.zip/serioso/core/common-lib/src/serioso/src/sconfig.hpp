

#ifndef _SCONFIG_H_
#define _SCONFIG_H_


#define LIBAPI extern "C"
//#define LUAJIT_VERSION

//#define WIN32

#ifdef WIN32
#include <Malloc.h>
#else
#include <stdlib.h>
#endif


#endif //_CONFIG_H_
