

#ifndef _S_LBYTEBUFFER_H_
#define _S_LBYTEBUFFER_H_

#include "llua.hpp"

void lbytebuffer_init();
void lbytebuffer_lreg(lua_State *L);

#endif
