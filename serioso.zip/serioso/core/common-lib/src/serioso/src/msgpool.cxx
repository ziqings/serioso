
#include <vector>
#include <pthread.h>

#include "squeue.hpp"
#include "msgcontext.hpp"
#include "msgpool.hpp"

using namespace std;


static vector<const SQueue *> idlepool;
static vector<int> sizes;
static int maxcapacity;
static int capacity_step;

static pthread_mutex_t poollock;


void msgpool_init(int maxcap, int step)
{
	sizes.push_back(64);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(512);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(1024);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(1024 * 64);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(1024 * 512);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(1024 * 1024);
	idlepool.push_back(squeue_gennew());

	sizes.push_back(1024 * 1024 * 2);
	idlepool.push_back(squeue_gennew());

	if(maxcap > (1024 * 1024 * 2))
	{
		sizes.push_back(maxcap);
		idlepool.push_back(squeue_gennew());
	}

	maxcapacity = maxcap;
	capacity_step = step;

	pthread_mutex_init(&poollock, NULL);
}

const MsgContext * msgpool_gencontext(int len)
{
	if(len <= 0)
		return NULL;
	int capacity = 0;
	int cap = 1024;
	int capacityindex = -1;
	for(int i = 0, count = sizes.size(); i < count; i++)
	{
		cap = sizes[i];
		if(cap >= len)
		{
			capacity = cap;
			capacityindex = i;
			break;
		}
	}

	if(capacity == 0)
		return NULL;

	pthread_mutex_lock(&poollock);

	const SQueue *idle = idlepool[capacityindex];

	const MsgContext *context = (const MsgContext *)squeue_dequeue(idle);

	if(context == NULL)
		context = msgcontext_gennew(capacity);
	pthread_mutex_unlock(&poollock);

	return context;
}

void msgpool_recyclecontext(const MsgContext *context)
{
	if(context == NULL)
		return;

	if(!msgcontext_active(context))
		return;

	int cap;
	int capacity = msgcontext_capacity(context);
	int capacityindex = -1;
	for(int i = 0, count = sizes.size(); i < count; i++)
	{
		cap = sizes[i];
		if(cap >= capacity)
		{
			capacityindex = i;
			break;
		}
	}

	if(capacity >= 0)
	{
		const SQueue *idle = idlepool[capacityindex];
		squeue_enqueue(idle, (void *)context);
	}
	else
	{
	}
}
