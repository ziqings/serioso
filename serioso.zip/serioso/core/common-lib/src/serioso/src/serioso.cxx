

#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdarg.h>

#include "sconfig.hpp"
#include "serioso.hpp"
#include "msgpool.hpp"
#include "lbytebuffer.hpp"
#include "log.hpp"
#include "platform.hpp"

using namespace serioso;

#ifdef WIN32
#include <Windows.h>
#include <DbgHelp.h>
#endif

static debug_func debug_log = NULL;

static pthread_mutex_t loglock;
static pthread_mutex_t stacklock;
static const int LOGBUFFLEN = 1024 * 64;
static char logbuf[LOGBUFFLEN];


void serioso_debug(const char *format, ...) 
{
	if(format == NULL)
		return;
	if(debug_log != NULL)
	{
		pthread_mutex_lock(&loglock);

		va_list arglist;
		va_start(arglist, format);
		vsnprintf(logbuf, LOGBUFFLEN, format, arglist); 
		va_end(arglist);

		debug_log(logbuf);
		pthread_mutex_unlock(&loglock);
	}
}

#ifdef WIN32
void serioso_printstack()  
{  
	pthread_mutex_lock(&stacklock);
	unsigned int i;  
	void * stack[ 100 ];  
	unsigned short frames;  
	SYMBOL_INFO * symbol;  
	HANDLE process;

	const int alllen = 1024 * 1024 * 128;
	static char allbuf[alllen];
	memset(allbuf, 0, alllen);

	process = GetCurrentProcess();  

	SymInitialize(process, NULL, TRUE);  

	frames = CaptureStackBackTrace( 0, 100, stack, NULL );  
	symbol = ( SYMBOL_INFO * )calloc( sizeof( SYMBOL_INFO ) + 256 * sizeof( char ), 1 );  
	symbol->MaxNameLen = 255;  
	symbol->SizeOfStruct = sizeof( SYMBOL_INFO );  

	const int slen = 1024 * 1024;
	static char sbuf[slen];
	int len = 0;
	int xlen = 0;
	for( i = 0; i < frames; i++ )  
	{  
		memset(sbuf, 0, slen);
		SymFromAddr( process, ( DWORD64 )( stack[ i ] ), 0, symbol );  

		xlen = sprintf(sbuf, "%i: %s - 0x%0X\n", frames - i - 1, symbol->Name, symbol->Address);

		memcpy(allbuf + len, sbuf, slen);
		len += xlen;
	}

	serioso_debug("stack------------------------->%s", allbuf);

	free( symbol );  
	pthread_mutex_unlock(&stacklock);
}
#else
void serioso_printstack()
{
}
#endif

static int lserioso_is_little_endian(lua_State *L)
{
	lua_pushboolean(L, platform_c::getcurrent()->is_little_endian());
	return 1;
}

static const struct luaL_Reg lua_funcs[] = 
{
	{"is_little_endian", lserioso_is_little_endian},
	{NULL, NULL}
};

void serioso_lreg(lua_State *L)
{
	llua_reg_module(L, "serioso", lua_funcs);
}

LIBAPI void serioso_init(debug_func func, int msg_max)
{
	debug_log = func;
	log_init(func);

	platform_c::init();
	pthread_mutex_init(&loglock, NULL);
	pthread_mutex_init(&stacklock, NULL);
	msgpool_init(msg_max, 1024 * 128);
	lbytebuffer_init();
}
