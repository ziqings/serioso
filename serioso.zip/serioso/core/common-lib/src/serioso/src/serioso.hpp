
#ifndef _SERIOSO_H_
#define _SERIOSO_H_

#include "llua.hpp"

void serioso_debug(const char *fmt, ...);
void serioso_printstack();
void serioso_lreg(lua_State *L);

#endif
