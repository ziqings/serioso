

#include "queue_sf.hpp"
#include "bytebuffer.hpp"
#include "common.hpp"
#include "lbytebuffer.hpp"
#include "serioso.hpp"

#include <vector>
#include <pthread.h>

using namespace std;
using namespace serioso;


static vector<bytebuffer_c *> pool;
static queue_sf_c<s_int> idlepool;

static pthread_mutex_t poollock;


static bytebuffer_c * getbuffer(s_int index)
{
	if(index < 0 || index >= pool.size())
		return NULL;

	return pool[index];
}

static int lbytebuffer_remaining(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		lua_pushinteger(L, buf->remaining());
	else
		lua_pushinteger(L, -1);

	return 1;
}

static int lbytebuffer_gennew(lua_State *L)
{
	s_int size = lua_tointeger(L, 1);
	if(size > 0)
	{
		s_int idle = -1;
		s_int re = idlepool.dequeue(&idle);
		if(re == 0)
		{
			bytebuffer_c *bbb = getbuffer(idle);
			bbb->clear();
			lua_pushinteger(L, idle);
			return 1;
		}

		pthread_mutex_lock(&poollock);
		bytebuffer_c *bb = new bytebuffer_c(size);
		bb->clear();
		idle = pool.size();
		bb->set_id(idle);
		pool.push_back(bb);
		pthread_mutex_unlock(&poollock);

		lua_pushinteger(L, idle);
	}
	else
		lua_pushinteger(L, -1);

	return 1;
}

static int lbytebuffer_dispose(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->clear();

	idlepool.enqueue(index);

	return 0;
}

static int lbytebuffer_clear(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->clear();

	return 0;
}

static int lbytebuffer_size(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->size());

	return 1;
}

static int lbytebuffer_peek(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->peek());

	return 1;
}

static int lbytebuffer_get(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->get());

	return 1;
}

static int lbytebuffer_get_bytes(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_int len = lua_tointeger(L, 2);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushnil(L);
	else
	{
		int rpos = buf->get_readpos();
		const s_byte *buff = buf->get_bytes();
		lua_pushlstring(L, (const char *)buff, len);
		buf->set_readpos(rpos + len);
	}

	return 1;
}

static int lbytebuffer_get_data(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
	{
		lua_pushnil(L);
	}
	else
	{
		buf->set_readpos(0);
		s_int len = buf->get_writepos();
		s_byte buff[len];
		buf->get_bytes(buff, len);
		lua_pushlstring(L, (const char *)buff, len);
	}

	return 1;
}

static int lbytebuffer_get_double(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushnumber(L, -1);
	else
		lua_pushnumber(L, buf->get_double());

	return 1;
}

static int lbytebuffer_get_float(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushnumber(L, -1);
	else
		lua_pushnumber(L, buf->get_float());

	return 1;
}

static int lbytebuffer_get_int(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
	{
		s_int iv = buf->get_int();
		lua_pushinteger(L, iv);
	}

	return 1;
}

static int lbytebuffer_get_long(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushnumber(L, -1);
	else
		lua_pushnumber(L, buf->get_long());

	return 1;
}

static int lbytebuffer_get_short(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushnumber(L, -1);
	else
		lua_pushnumber(L, buf->get_short());

	return 1;
}

static int lbytebuffer_get_ushort(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->get_ushort());

	return 1;
}

static int lbytebuffer_put(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_byte v = (s_byte)lua_tonumber(L, 2);
	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put(v);

	return 0;
}

static int lbytebuffer_put_bytes(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	size_t len = 0;
	const s_byte *arr = (const s_byte *)(const char *)lua_tolstring(L, 2, &len);
	if(arr == NULL)
		return 0;
	if(len <= 0)
		return 0;

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_bytes(arr, (s_int)len);

	return 0;
}

static int lbytebuffer_put_string(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	const char *arr = lua_tostring(L, 2);
	if(arr == NULL)
	{
		lua_pushinteger(L, 0);
		return 1;
	}

	s_int len = strlen(arr);
	if(len <= 0)
		return 0;

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_bytes((const s_byte *)arr, len);

	lua_pushinteger(L, len);

	return 1;
}

static int lbytebuffer_put_double(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_double v = lua_tonumber(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_double(v);

	return 0;
}

static int lbytebuffer_put_float(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_float v = lua_tonumber(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_float(v);

	return 0;
}

static int lbytebuffer_put_int(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_int v = lua_tointeger(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_int(v);

	return 0;
}

static int lbytebuffer_put_long(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_long v = lua_tonumber(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_long(v);

	return 0;
}

static int lbytebuffer_put_short(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_short v = lua_tointeger(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_short(v);

	return 0;
}

static int lbytebuffer_put_ushort(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_ushort v = lua_tointeger(L, 2);

	bytebuffer_c *buf = getbuffer(index);
	if(buf != NULL)
		buf->put_ushort(v);

	return 0;
}

static int lbytebuffer_set_readpos(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_int pos = lua_tointeger(L, 2);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
	{
		if(pos < 0 || pos >= buf->size())
			lua_pushinteger(L, -2);
		else
		{
			buf->set_readpos(pos);
			lua_pushinteger(L, pos);
		}
	}

	return 1;
}

static int lbytebuffer_get_readpos(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->get_readpos());

	return 1;
}

static int lbytebuffer_set_writepos(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_int pos = lua_tointeger(L, 2);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
	{
		if(pos < 0 || pos >= buf->size())
			lua_pushinteger(L, -2);
		else
		{
			buf->set_writepos(pos);
			lua_pushinteger(L, pos);
		}
	}

	return 1;
}

static int lbytebuffer_get_writepos(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		lua_pushinteger(L, -1);
	else
		lua_pushinteger(L, buf->get_writepos());

	return 1;
}

static int lbytebuffer_set_little_endian(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	s_bool v = lua_toboolean(L, 2);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		return 0;

	buf->set_little_endian(v);
	return 0;
}

static int lbytebuffer_set_system_endian(lua_State *L)
{
	s_int index = lua_tointeger(L, 1);
	bytebuffer_c *buf = getbuffer(index);
	if(buf == NULL)
		return 0;

	buf->set_little_endian(platform_c::getcurrent()->is_little_endian());
	return 0;
}

static const struct luaL_Reg sbytebuffer_funcs[] = 
{
	{"remaining", lbytebuffer_remaining},
	{"gennew", lbytebuffer_gennew},
	{"dispose", lbytebuffer_dispose},
	{"clear", lbytebuffer_clear},
	{"size", lbytebuffer_size},
	{"peek", lbytebuffer_peek},
	{"get", lbytebuffer_get},
	{"get_bytes", lbytebuffer_get_bytes},
	{"get_data", lbytebuffer_get_data},
	{"get_double", lbytebuffer_get_double},
	{"get_float", lbytebuffer_get_float},
	{"get_int", lbytebuffer_get_int},
	{"get_long", lbytebuffer_get_long},
	{"get_short", lbytebuffer_get_short},
	{"get_ushort", lbytebuffer_get_ushort},
	//{"get_string", lbytebuffer_get_string},
	{"put", lbytebuffer_put},
	{"put_bytes", lbytebuffer_put_bytes},
	{"put_string", lbytebuffer_put_string},
	{"put_double", lbytebuffer_put_double},
	{"put_float", lbytebuffer_put_float},
	{"put_int", lbytebuffer_put_int},
	{"put_long", lbytebuffer_put_long},
	{"put_short", lbytebuffer_put_short},
	{"put_ushort", lbytebuffer_put_ushort},
	{"set_readpos", lbytebuffer_set_readpos},
	{"get_readpos", lbytebuffer_get_readpos},
	{"set_writepos", lbytebuffer_set_writepos},
	{"get_writepos", lbytebuffer_get_writepos},
	{"set_little_endian", lbytebuffer_set_little_endian},
	{"set_system_endian", lbytebuffer_set_system_endian},
	{NULL, NULL}
};

void lbytebuffer_lreg(lua_State *L)
{
	llua_reg_module(L, "sbytebuffer", sbytebuffer_funcs);
	serioso_debug("lua bytebuffer init");
}

void lbytebuffer_init()
{
	pthread_mutex_init(&poollock, NULL);
}
