

#ifndef _S_QUEUE_H_
#define _S_QUEUE_H_

struct SQueue;

void squeue_init();

const SQueue * squeue_gennew();

void squeue_dispose(const SQueue *);

int squeue_enqueue(const SQueue *, void *);


void * squeue_dequeue(const SQueue *);

#endif //_S_QUEUE_H_
