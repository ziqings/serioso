
#include <string.h>
#include <unistd.h>

#include "msgpool.hpp"
#include "squeue.hpp"
#include "msgcontext.hpp"
#include "llua.hpp"
#include "sconfig.hpp"
#include "serioso.hpp"
#include "lbytebuffer.hpp"
#include "log.hpp"

#ifdef WIN32
#include <windows.h>
#endif

#include <vector>
#include <pthread.h>

using namespace std;
using namespace serioso;



struct Proc
{
	lua_State *L;
	pthread_t thread;
	int channel;
	int luafunc_init;
	int luafunc_update;
	bool active;
	int sleeptime;
	const SQueue *recvqueue;
};


static vector<Proc *> procs;



static Proc * getproc(int channel)
{
	if(channel < 0 || channel >= procs.size())
		return NULL;

	return procs[channel];
}

static int regproc(int channel)
{
	if(channel < 0)
		return -1;

	bool doo = true;
	if(channel < procs.size())
	{
		Proc *p = procs[channel];
		if(p != NULL)
		{
			if(p->active)
				return -2;

			doo = false;
		}
	}

	if(doo)
	{
		for(int i = procs.size(); i <= channel; i++)
			procs.push_back(NULL);
		Proc *p = (Proc *)malloc(sizeof(*p));
		p->active = false;
		p->L = NULL;
		procs[channel] = p;
	}

	return 0;
}

LIBAPI int sthread_send(int channel, int gID, int uID, const char *msg, int len)
{
	Proc *p = getproc(channel);
	if(p == NULL)
		return -1;
	if(len > 999999999)
	{
		serioso_debug("send msg is invalid->%d, %d, %d, %d, %s", channel, gID, uID, len, msg);
		return -100;
	}
	const MsgContext *context = msgpool_gencontext(len);
	if(context == NULL)
		return -2;

	msgcontext_set(context, gID, uID, msg, len);
	squeue_enqueue(p->recvqueue, (void *)context);

	return 0;
}

static int sthread_lsend(lua_State *L)
{
	int top = lua_gettop(L);
	int channel = luaL_checknumber(L, 1);
	Proc *p = getproc(channel);
	if(p == NULL)
	{
		lua_settop(L, 1);
		lua_pushinteger(L, -1);
		return lua_gettop(L) - 1;
	}

	int gID = lua_tointeger(L, 2);
	int uID = lua_tointeger(L, 3);

	size_t len = -1;
	const char *msg = lua_tolstring(L, 4, &len);
	lua_pop(L, top);

	const MsgContext *context = msgpool_gencontext(len);
	if(context == NULL)
	{
		lua_pushinteger(L, -2);
		return 1;
	}
	msgcontext_set(context, gID, uID, msg, len);

	squeue_enqueue(p->recvqueue, (void *)context);

	lua_pushinteger(L, 0);
	return 1;
}

LIBAPI int sthread_receive(int channel, int &gID, int &uID, char *buf, int capacity)
{
	return -10000;
	Proc *proc = getproc(channel);
	if(proc != NULL)
	{
		void *item = squeue_dequeue(proc->recvqueue);
		if(item != NULL)
		{
			const MsgContext *context = (const MsgContext *)item;
			
			int msglen = msgcontext_get(context, gID, uID, buf, capacity);

			msgpool_recyclecontext(context);
			return msglen;
		}
		else
			return -200;
	}
	else
		return -100;

	return -300;
}

static int sthread_lreceive(lua_State *L)
{
	int channel = luaL_checknumber(L, 1);

	Proc *proc = getproc(channel);
	if(proc != NULL)
	{
		void *item = squeue_dequeue(proc->recvqueue);
		if(item != NULL)
		{
			const MsgContext *context = (const MsgContext *)item;
			int re = msgcontext_lget(context, L);

			msgpool_recyclecontext(context);
			lua_pushinteger(L, re);
		}
		else
		{
			lua_pushinteger(L, -1);
			lua_pushinteger(L, -1);
			lua_pushstring(L, "");
			lua_pushinteger(L, -200);
		}
	}
	else
	{
		lua_pushinteger(L, -1);
		lua_pushinteger(L, -1);
		lua_pushstring(L, "");
		lua_pushinteger(L, -100);
	}

	return 4;
}

static void * sthread_lthread(void *arg);

static int sthread_lstart(lua_State *L)
{
	int channel = luaL_checknumber(L, 1);

	Proc *proc = getproc(channel);
	if(proc == NULL)
		return -1;

	pthread_t thread;
	if(pthread_create(&thread, NULL, sthread_lthread, &(proc->channel)) != 0)
	{
		luaL_error(L, "create new thread failed");
		return -2;
	}

	pthread_detach(thread);

	return 0;
}

static int sthread_lexit(lua_State *L)
{
	pthread_exit(NULL);
	return 0;
}

static const struct luaL_Reg sthread_funcs[] = 
{
	{"start", sthread_lstart},
	{"send", sthread_lsend},
	{"receive", sthread_lreceive},
	{"exit", sthread_lexit},
	{NULL, NULL}
};

static void * sthread_lthread(void *arg)
{
	int channel = *(int*)arg;

	Proc *proc = getproc(channel);
	if(proc == NULL)
	{
		serioso_debug("channel process get proc is null->%d", channel);
		return NULL;
	}

	if(proc->luafunc_update < 0)
		return NULL;

	proc->thread = pthread_self();
	if(proc->sleeptime <= 0)
		proc->sleeptime = 100;
	proc->active = true;

	int top = -1;
	while(proc->active)
	{
		top = llua_beginpcall(proc->L, proc->luafunc_update);
		if(lua_pcall(proc->L, 0, -1, top) != 0)
		{
			const char *msg = lua_tostring(proc->L, -1);
			serioso_debug("call thread update func error->%s", msg);
		}

#ifdef WIN32
		Sleep(proc->sleeptime);
#else
		usleep(proc->sleeptime * 1000);
#endif
	}

	proc->L = NULL;
	serioso_debug("thread exit channel->%d", proc->channel);

	return NULL;
}

LIBAPI int sthread_lcreate(lua_State *L, int channel, int init_reference, int update_reference, int sleep_time)
{
	int re = regproc(channel);
	if(re < 0)
		return re;

	Proc *proc = getproc(channel);
	if(proc == NULL)
		return -100;

	proc->L = L;
	proc->channel = channel;
	proc->luafunc_init = init_reference;
	proc->luafunc_update = update_reference;
	proc->recvqueue = squeue_gennew();
	proc->sleeptime = sleep_time;

	llua_reg_module(proc->L, "sthread", sthread_funcs);
	lbytebuffer_lreg(proc->L);
	serioso_lreg(proc->L);

	int top = llua_beginpcall(L, proc->luafunc_init);
	if(lua_pcall(L, 0, -1, top) != 0)
	{
		const char *msg = lua_tostring(proc->L, -1);
		serioso_debug("call thread init func error->%s", msg);
	}

	return 0;
}

LIBAPI int sthread_create(int channel)
{
	int re = regproc(channel);
	if(re < 0)
		return re;

	Proc *proc = getproc(channel);
	if(proc == NULL)
		return -100;

	proc->channel = channel;
	proc->recvqueue = squeue_gennew();
	proc->luafunc_update = -1;
	proc->luafunc_init = -1;

	return 0;
}

LIBAPI void sthread_close(int channel)
{
	Proc *proc = getproc(channel);
	if(proc == NULL)
		return;

	proc->active = false;
}
