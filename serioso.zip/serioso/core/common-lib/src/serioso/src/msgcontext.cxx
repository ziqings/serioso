

#include <vector>
#include <queue>
#include <string.h>

#ifdef WIN32
#include <Malloc.h>
#else
#include <stdlib.h>
#endif

#include "msgcontext.hpp"
#include "llua.hpp"
#include "serioso.hpp"

using namespace std;



struct MsgContext
{
    int id;
    int capacity;
    int len;
    int gID;
    int uID;
    bool active;
	char *buf;
};

static vector<MsgContext *> contexts;
static queue<int> idlecontexts;


const MsgContext * msgcontext_gennew(int len)
{
	size_t index = -1;

	if(idlecontexts.size() > 0)
	{
		index = idlecontexts.front();
		idlecontexts.pop();
	}
	else
	{
		index = contexts.size();
		MsgContext *context = (MsgContext *)malloc(sizeof(*context));
		contexts.push_back(context);
	}

	if(len > 999999999)
	{
		serioso_debug("msg gen len is invalid->%d", len);
		serioso_printstack();
	}

	MsgContext *context = contexts[index];
	context->capacity = len;
	context->len = 0;
	context->id = (int)index;
	context->active = true;
	context->buf = (char *)malloc(sizeof(char) * len);

	return context;
}

void msgcontext_dispose(const MsgContext *context)
{
	if(context == NULL)
		return;
	if(!context->active)
		return;

	MsgContext *t = contexts[context->id];
	t->active = false;

	idlecontexts.push(t->id);
}

int msgcontext_capacity(const MsgContext *context)
{
	if(context == NULL)
		return 0;

	return context->capacity;
}

bool msgcontext_active(const MsgContext *context)
{
	if(context == NULL)
		return 0;

	return context->active;
}

int msgcontext_set(const MsgContext *context, int gID, int uID, const char *data, int len)
{
	if(len <= 0)
		return -1;
	if(data == NULL)
		return -2;
	if(context == NULL)
		return -3;
	if(!context->active)
		return -4;
	if(len > context->capacity)
		return -5;

	MsgContext *t = contexts[context->id];

	t->gID = gID;
	t->uID = uID;
	memcpy(t->buf, data, len);
	t->len = len;

	return 0;
}

int msgcontext_lget(const MsgContext *context, lua_State *L)
{
	if(context == NULL)
		return -1;
	if(L == NULL)
		return -2;
	if(!context->active)
		return -3;
	if(context->len <= 0)
		return -4;

	if(context->buf == NULL)
		return -5;
	if(L == NULL)
		return -6;

    lua_pushinteger(L, context->gID);
	lua_pushinteger(L, context->uID);
	lua_pushlstring(L, context->buf, context->len);

	return 0;
}

int msgcontext_get(const MsgContext *context, int &gID, int &uID, char *buf, int len)
{
	if(context == NULL)
		return -1;
	if(!context->active)
		return -2;
	if(context->len <= 0)
		return -3;
	if(context->len > len)
		return -4;

	gID = context->gID;
	uID = context->uID;
	memcpy(buf, context->buf, context->len);

	return context->len;
}
